const audioDebutNiveau = new Audio("../Son/DebutNiveau.wav"),
    audioTresor =  new Audio("../Son/PrendreRamen.wav"),
    audioMur =  new Audio("../Son/detruireMur.wav"),
    audioSucces =  new Audio("../Son/GameOver.wav"),
    audioEchec =  new Audio("../Son/perdreVie.wav"),
    audioRecommencer =  new Audio("../Son/tomber.wav");