var intScore = 300;

